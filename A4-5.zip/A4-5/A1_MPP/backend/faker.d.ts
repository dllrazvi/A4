declare module 'faker' {
    const faker: any;
    export default faker;
  }
  